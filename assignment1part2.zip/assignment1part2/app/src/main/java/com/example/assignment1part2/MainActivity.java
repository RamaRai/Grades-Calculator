package com.example.assignment1part2;
//Mobile App Development Course - Seneca College 2019
//Assignment 1 Part2 Grades Calculator (Free App Version 1)
// Submitted to : Paulo Treves
// Submitted by Rama K. Rai ( Student Id : 125423194 )

import android.content.Intent;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // LOGTAG used to log in LogCat for debugging purpose
    public static final String LOGTAG = "Assignment1Part2";

    //Local EditText Variables these will get attached to the view in layout
    EditText androidText;
    EditText javaText;
    EditText kotlinText;
    EditText xmlText;

    Button bClick;

    int myAndroid=0;
    int myJava=0;
    int myKotlin=0;
    int myXml=0;

    int avrage=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.v(LOGTAG, "1. Rama Rai student ID: 125423194");

        //finds the view from the layout resource file and attach it to a local EditText variable in current Activity.
        //setFilter on EditText Variables by passing input to MinMaxFilter Java Class
        androidText = findViewById(R.id.androids);
        androidText.setFilters(new InputFilter[]{new MinMaxFilter("0", "99")});
        javaText = findViewById(R.id.java);
        javaText.setFilters(new InputFilter[] {new MinMaxFilter("0", "99")});
        kotlinText = findViewById(R.id.kotlin);
        kotlinText.setFilters(new InputFilter[] {new MinMaxFilter("0", "99")});
        xmlText = findViewById(R.id.xml);
        xmlText.setFilters(new InputFilter[] {new MinMaxFilter("0", "99")});

        bClick = findViewById(R.id.Calc);
        // Log to log the statement in LogCat for debugging purpose
        Log.v(LOGTAG, "2. Marks Input Restrictions applied");

    }

    //Creating a menu with options
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        super.onCreateOptionsMenu(menu);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu,menu);

        return true;
    }

    //Action performed respective to the option selected
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        super.onOptionsItemSelected(item);
        // Log to log the statement in LogCat for debugging purpose
        Log.v(LOGTAG, "3. Invoked menu item About");
        switch (item.getItemId()){
            case R.id.menu_About_dialog:
                Intent aboutIntent = new Intent(this, About.class);
                startActivity(aboutIntent);
                break;
        }
        return true;
    }


    //method invoked when the Calculate button on the Activity layout is clicked
    public void calculation(View view) {


        //Null value Error handling if user doesn't enter any grade and yet press the button Calculate

        if (androidText.getText().toString().matches("")){
            myAndroid=0;
        }else {
            myAndroid = Integer.parseInt(androidText.getText().toString());
        }
        if (javaText.getText().toString().matches("")){
            myJava=0;
        }else {
            myJava = Integer.parseInt(javaText.getText().toString());
        }
        if (kotlinText.getText().toString().matches("")){
            myKotlin=0;
        }else {
            myKotlin = Integer.parseInt(kotlinText.getText().toString());
        }
        if (xmlText.getText().toString().matches("")){
            myXml=0;
        }else {
            myXml = Integer.parseInt(xmlText.getText().toString());
        }


        avrage = ((myAndroid+myJava+myKotlin+myXml)/4);
        //Log to make sure average is calculated in case og debugging
        Log.v(LOGTAG, avrage+" average last in this Activity");

        //Create Bundle Object for the Intent by putting Key Value pair
        Bundle bundle = new Bundle();

        bundle.putInt("myKeyAndroid",myAndroid);
        bundle.putInt("myKeyJava",myJava);
        bundle.putInt("myKeyKotlin",myKotlin);
        bundle.putInt("myKeyXml",myXml);
        bundle.putInt("myKeyAvg",avrage);

        //Creating Intent object to pass the values as Bundle from one Activity to Next Activity
        Intent i = new Intent(MainActivity.this,ResultsActivity.class);
        i.putExtras(bundle);


        //Start the next Activity by showing it on device as current
        startActivity(i);

    }


}
