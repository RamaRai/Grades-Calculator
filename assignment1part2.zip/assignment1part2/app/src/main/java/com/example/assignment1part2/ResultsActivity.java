package com.example.assignment1part2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ResultsActivity extends AppCompatActivity {

    //Local TextView Variables these will get attached to the view in layout
    TextView androidtmp, javatmp, kotlintmp, xmltmp,gradetmp;

    // LOGTAG used to log in LogCat for debugging purpose
    public static final String LOGTAG = "Assignment1Part2";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        //finds the view from the layout resource file and attach it to a local TextView variable in current Activity.
        androidtmp=findViewById(R.id.androidresult);
        javatmp=findViewById(R.id.javaresult);
        kotlintmp=findViewById(R.id.kotlinresult);
        xmltmp=findViewById(R.id.xmlresult);
        gradetmp=findViewById(R.id.avgGrades);

        //Receiving the value as per the key from the intent and assigning it to local variable
        //also in case of Null assigning a default value 0

        int recAndroid = getIntent().getIntExtra("myKeyAndroid",0);
        int recJava = getIntent().getIntExtra("myKeyJava",0);
        int recKotlin = getIntent().getIntExtra("myKeyKotlin",0);
        int recXml = getIntent().getIntExtra("myKeyXml",0);
        int recAvg = getIntent().getIntExtra("myKeyAvg",0);

        Log.v(LOGTAG, "1.ResultActivity Received Value from the Intent");

        androidtmp.setText(String.valueOf(recAndroid));
        javatmp.setText(String.valueOf(recJava));
        kotlintmp.setText(String.valueOf(recKotlin));
        xmltmp.setText(String.valueOf(recXml));
        gradetmp.setText(String.valueOf(recAvg));

        Log.v(LOGTAG, "2.ResultActivity Assigned Value to views on layout");
    }

    public void comeback(View view) {
        Log.v(LOGTAG, "3. Back Button OnClick");
        finish();
        Log.v(LOGTAG, "4.Going to Back Activity");
     //   onBackPressed();

    }
}
